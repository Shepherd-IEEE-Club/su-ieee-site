\* theme by NomnomNami! *\
thank you for downloading!
i hope it helps you make a cute website :)


= installation instructions =

>> if you use the neocities editor:
go to https://neocities.org/dashboard and drop each file from inside the folder into your site (except for this readme haha)
if you already have some text on your homepage (index.html) make sure you copy it first so you can transfer it into the new version!

>> if you edit your site locally on your pc:
drop the files into your site's folder instead of directly into neocities
again, be sure to keep a backup of your site--you can always redownload your public files from neocities too.

that's it, you're ready to edit your page now!
if you want to make more pages using the same template, just make a copy of index.html


= editing the files =

* you should replace the text in index.html with any info you want to put on your website!
* you can replace the pictures in the images folder too. (it's ok to keep mine if you want, though!)
NOTE: when replacing the images, it's good to keep them around the same size as the existing ones. you can edit the css if you want custom sizes though!
* there's a lot you can customize in style.css - i left lots of comments explaining what most of it does, but the colors are at the very top so you can swap them out easily!


= thanks again for downloading! =

i can't offer further support, but there are plenty of resources online explaining how to use css and html.
go forth and make a cute website! have fun!!!

<3 nami